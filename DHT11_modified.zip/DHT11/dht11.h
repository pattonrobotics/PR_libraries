// 
//    FILE: dht11.h
// VERSION: 0.3.2
// PURPOSE: DHT11 Temperature & Humidity Sensor library for Arduino
// LICENSE: GPL v3 (http://www.gnu.org/licenses/gpl.html)
//
// DATASHEET: http://www.micro4you.com/files/sensor/DHT11.pdf
//
//     URL: http://arduino.cc/playground/Main/DHT11Lib
//
// HISTORY:
// George Hadjikyriacou - Original version
// see dht.cpp file
// *** Terry King: Changed include Arduino.h for 1.0x  
// include core Wiring API and now Arduino
// Brian Patton: Added decimal values for both temperature and Humidity
// + added conversions to Fahrenheit and Kalvin 
#if defined(ARDUINO) && ARDUINO >= 100
  #include "Arduino.h"
  #else
  #include "WProgram.h"
  #endif

#ifndef dht11_h
#define dht11_h

#define DHT11LIB_VERSION "0.3.2"

class dht11
{
public:
    int read(int pin);
	int humidityWhole;		// Holder for the whole number in humidity
	int humidityDecimal;	// Holder for the decimal number in humidity	
	int temperatureWhole;	// Holder for the whole number in temperature	
	int tempDecimal;		// Holder for the decimal number in temperature	
	float temperatureC;		// Variable to hold the combined whole and decimal value for temperature in Celcius
	float temperatureF;		// Variable to hold the combined whole and decimal value for temperature in Fahrenheit 
	float temperatureK;		// Variable to hold the combined whole and decimal value for temperature in Kelvin
	float humidity;			// Variable to hold the combined whole and decimal value for humidity
};
#endif
//
// END OF FILE
//